import React from 'react'
import Header4 from './Header4'
import Footer from './Footer'
function Resumedetail() {
  return (

    <><>
    <Header4/>
    {/* ======================= Start Page Title ===================== */}
    <div className="page-title">
      <div className="container">
        <div className="page-caption">
          <h2>Resume Detail</h2>
          <p>
            <a href="#" title="Home">
              Home
            </a>{" "}
            <i className="ti-angle-double-right" /> Resume Detail
          </p>
        </div>
      </div>
    </div>
    {/* ======================= End Page Title ===================== */}
    {/* ====================== Resume Detail ================ */}
    <section className="padd-top-80 padd-bot-80">
      <div className="container">
        <div className="row">
          <div className="col-md-8 col-sm-7">
            <div className="detail-wrapper">
              <div className="detail-wrapper-body">
                <div className="row">
                  <div className="col-md-4 text-center user_profile_img mrg-bot-30">
                    {" "}
                    <img
                      src="assets/img/client-1.jpg"
                      className="img-circle width-100"
                      alt=""
                    />
                    <h4 className="meg-0">Alden Smith</h4>
                    <span>Front End Designer</span>
                  </div>
                  <div className="col-md-8 user_job_detail">
                    <div className="col-md-12 mrg-bot-10">
                      {" "}
                      <i className="ti-location-pin padd-r-10" />
                      2726 Shinn, New York{" "}
                    </div>
                    <div className="col-md-12 mrg-bot-10">
                      {" "}
                      <i className="ti-email padd-r-10" />
                      mail@example.com{" "}
                    </div>
                    <div className="col-md-12 mrg-bot-10">
                      {" "}
                      <i className="ti-mobile padd-r-10" />
                      91 234 567 8765{" "}
                    </div>
                    <div className="col-md-12 mrg-bot-10">
                      {" "}
                      <i className="ti-credit-card padd-r-10" />
                      $12/Hour{" "}
                    </div>
                    <div className="col-md-12 mrg-bot-10">
                      {" "}
                      <i className="ti-shield padd-r-10" />3 Year Exp.{" "}
                    </div>
                    <div className="col-md-12 mrg-bot-10">
                      {" "}
                      <span className="skill-tag">css</span>{" "}
                      <span className="skill-tag">HTML</span>{" "}
                      <span className="skill-tag">Photoshop</span>{" "}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="detail-wrapper">
              <div className="detail-wrapper-header">
                <h4>Career</h4>
              </div>
              <div className="detail-wrapper-body">
                <p>
                  Contrary to popular belief, Lorem Ipsum is not simply random
                  text. It has roots in a piece of classical Latin literature from
                  45 BC, making it over 2000 years old. Richard McClintock, a
                  Latin professor at Hampden-Sydney College in Virginia, looked up
                  one of the more obscure Latin words, consectetur.
                </p>
                <p>
                  The point of using Lorem Ipsum is that it has a more-or-less
                  normal distribution of letters, as opposed to using 'Content
                  here, content here', making it look like readable English.
                </p>
              </div>
            </div>
            <div className="detail-wrapper">
              <div className="detail-wrapper-header">
                <h4>Education</h4>
              </div>
              <div className="detail-wrapper-body">
                <div className="edu-history info">
                  {" "}
                  <i />
                  <div className="detail-info">
                    <h3>University</h3>
                    <i>2020 - 2020</i>{" "}
                    <span>
                      {" "}
                      denouncing pleasure and praising pain <i>It Computer</i>
                    </span>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Proin a ipsum tellus. Interdum et malesuada fames ac ante
                      ipsum primis in faucibus.
                    </p>
                  </div>
                </div>
                <div className="edu-history danger">
                  {" "}
                  <i />
                  <div className="detail-info">
                    <h3>Intermediate School</h3>
                    <i>2015 - 2020</i>{" "}
                    <span>
                      denouncing pleasure and praising pain <i>It Computer</i>
                    </span>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Proin a ipsum tellus. Interdum et malesuada fames ac ante
                      ipsum primis in faucibus.
                    </p>
                  </div>
                </div>
                <div className="edu-history success">
                  {" "}
                  <i />
                  <div className="detail-info">
                    <h3>High School</h3>
                    <i>2012 - 2015</i>{" "}
                    <span>
                      denouncing pleasure and praising pain <i>It Computer</i>
                    </span>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Proin a ipsum tellus. Interdum et malesuada fames ac ante
                      ipsum primis in faucibus.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="detail-wrapper">
              <div className="detail-wrapper-header">
                <h4>Work &amp; Experience</h4>
              </div>
              <div className="detail-wrapper-body">
                <div className="edu-history info">
                  {" "}
                  <i />
                  <div className="detail-info">
                    <h3>Php Developer</h3>
                    <i>2008 - 2012</i>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Proin a ipsum tellus. Interdum et malesuada fames ac ante
                      ipsum primis in faucibus.
                    </p>
                  </div>
                </div>
                <div className="edu-history danger">
                  {" "}
                  <i />
                  <div className="detail-info">
                    <h3>Java Developer</h3>
                    <i>2012 - 2014</i>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Proin a ipsum tellus. Interdum et malesuada fames ac ante
                      ipsum primis in faucibus.
                    </p>
                  </div>
                </div>
                <div className="edu-history success">
                  {" "}
                  <i />
                  <div className="detail-info">
                    <h3>CMS Developer</h3>
                    <i>2014 - 2018</i>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Proin a ipsum tellus. Interdum et malesuada fames ac ante
                      ipsum primis in faucibus.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Sidebar */}
          <div className="col-md-4 col-sm-5">
            <div className="sidebar">
              <div className="widget-boxed">
                <div className="text-center">
                  <button type="submit" className="btn btn-m btn-primary">
                    Download Resume
                  </button>
                </div>
              </div>
              <div className="widget-boxed">
                <div className="widget-boxed-header">
                  <h4>
                    <i className="ti-location-pin padd-r-10" />
                    Location
                  </h4>
                </div>
                <div className="widget-boxed-body">
                  <div className="side-list no-border">
                    <ul>
                      <li>
                        <i className="ti-credit-card padd-r-10" />
                        Package: 20K To 50K/Month
                      </li>
                      <li>
                        <i className="ti-world padd-r-10" />
                        https://www.example.com
                      </li>
                      <li>
                        <i className="ti-mobile padd-r-10" />
                        91 234 567 8765
                      </li>
                      <li>
                        <i className="ti-email padd-r-10" />
                        mail@example.com
                      </li>
                      <li>
                        <i className="ti-pencil-alt padd-r-10" />
                        Bachelor Degree
                      </li>
                      <li>
                        <i className="ti-shield padd-r-10" />3 Year Exp.
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              {/* End: Job Overview */}
              {/* Start: Opening hour */}
              <div className="widget-boxed">
                <div className="widget-boxed-header">
                  <h4>
                    <i className="ti-headphone padd-r-10" />
                    Contact Now
                  </h4>
                </div>
                <div className="widget-boxed-body">
                  <form>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Name *"
                    />
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Email *"
                    />
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Phone"
                    />
                    <textarea
                      className="form-control height-140"
                      placeholder="Message..."
                      defaultValue={""}
                    />
                    <button className="btn theme-btn full-width mrg-bot-20">
                      Send Email
                    </button>
                  </form>
                </div>
              </div>
              {/* End: Opening hour */}
            </div>
          </div>
          {/* End Sidebar */}
        </div>
        {/* End Row */}
      </div>
    </section>
    {/* ====================== End Resume Detail ================ */}
  </>
  <Footer/>
  </>

  )
}

export default Resumedetail
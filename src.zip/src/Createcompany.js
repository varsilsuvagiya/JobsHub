import React from 'react'
import Header3 from './Header3'
import Footer from './Footer'
import { Link } from 'react-router-dom'
function Createcompany() {
  return (
   <>
   <Header3/>
       <>
  {/* ======================= Start Page Title ===================== */}
  <div className="page-title">
    <div className="container">
      <div className="page-caption">
        <h2>Create Company</h2>
        <p>
          <Link to="/home" title="Home">
            Home
          </Link>{" "}
          <i className="ti-angle-double-right" /> Create Company
        </p>
      </div>
    </div>
  </div>
  {/* ======================= End Page Title ===================== */}
  {/* ======================= Start Create Company ===================== */}
  <section className="utf_create_company_area padd-top-80 padd-bot-80">
    <div className="container">
      <form className="c-form">
        {/* General Information */}
        <div className="box">
          <div className="box-header">
            <h4>General Information</h4>
          </div>
          <div className="box-body">
            <div className="row">
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Company Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Company Name"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Company Tagline</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Company Tagline"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Category</label>
                <select className="wide form-control">
                  <option data-display="Location">
                    Information Of Technology
                  </option>
                  <option value={1}>Hardware</option>
                  <option value={2}>Machanical</option>
                </select>
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                <label>Owner Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Owner Name"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Company Logo</label>
                <div className="custom-file-upload">
                  <input type="file" id="file" name="myfiles[]" multiple="" />
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Established</label>
                <input
                  type="text"
                  placeholder="Established"
                  id="reservation-date"
                  data-lang="en"
                  data-large-mode="true"
                  data-min-year={2020}
                  data-max-year={2020}
                  data-disabled-days="08/17/2020,08/18/2020"
                  data-id="datedropper-0"
                  data-theme="my-style"
                  className="form-control"
                  readOnly=""
                />
              </div>
            </div>
          </div>
        </div>
        {/* Company Address */}
        <div className="box">
          <div className="box-header">
            <h4>Company Address</h4>
          </div>
          <div className="box-body">
            <div className="row">
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Email</label>
                <input
                  type="email"
                  className="form-control"
                  placeholder="Email"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Phone Number</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Phone Number"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Landline</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Landline"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Website Link</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Website Link"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Address</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Address"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>City</label>
                <select className="wide form-control">
                  <option data-display="City">Afghanistan</option>
                  <option value={1}>Albania</option>
                  <option value={2}>Algeria</option>
                  <option value={3}>Brazil</option>
                  <option value={4}>Burundi</option>
                  <option value={5}>Bulgaria</option>
                  <option value={6}>Germany</option>
                  <option value={7}>Grenada</option>
                  <option value={8}>Guatemala</option>
                  <option value={9} disabled="">
                    Iceland
                  </option>
                </select>
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                <label>State</label>
                <select className="wide form-control">
                  <option data-display="State">Afghanistan</option>
                  <option value={1}>Albania</option>
                  <option value={2}>Algeria</option>
                  <option value={3}>Brazil</option>
                  <option value={4}>Burundi</option>
                  <option value={5}>Bulgaria</option>
                  <option value={6}>Germany</option>
                  <option value={7}>Grenada</option>
                  <option value={8}>Guatemala</option>
                  <option value={9} disabled="">
                    Iceland
                  </option>
                </select>
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                <label>Country</label>
                <select className="wide form-control">
                  <option data-display="State">Afghanistan</option>
                  <option value={1}>Albania</option>
                  <option value={2}>Algeria</option>
                  <option value={3}>Brazil</option>
                  <option value={4}>Burundi</option>
                  <option value={5}>Bulgaria</option>
                  <option value={6}>Germany</option>
                  <option value={7}>Grenada</option>
                  <option value={8}>Guatemala</option>
                  <option value={9} disabled="">
                    Iceland
                  </option>
                </select>
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                <label>Zip Code</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Zip Code"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Employees</label>
                <select className="wide form-control">
                  <option data-display="Employees">10 - 50</option>
                  <option value={1}>50 - 100</option>
                  <option value={2}>100 - 500</option>
                  <option value={3} disabled="">
                    500 - 1000
                  </option>
                </select>
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                <label>Working Time</label>
                <select className="wide form-control">
                  <option data-display="Working Time">08:00AM To 5:00PM</option>
                  <option value={1}>10:00AM To 4:00PM</option>
                  <option value={2}>10:00AM To 6:00PM</option>
                  <option value={3} disabled="">
                    11:00AM To 7:00PM
                  </option>
                </select>
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                <label>Address 2</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Address Two"
                />
              </div>
            </div>
          </div>
        </div>
        {/* Social Accounts */}
        <div className="box">
          <div className="box-header">
            <h4>Social Accounts</h4>
          </div>
          <div className="box-body">
            <div className="row">
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Facebook</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://www.facebook.com/"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Google +</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://www.gmail.com/"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Twitter</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://twitter.com/"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>LinkedIn</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://www.linkedin.com/"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Pinterest</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://www.pinterest.com/"
                />
              </div>
              <div className="col-md-4 col-sm-6 col-xs-12">
                <label>Instagram</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="http://instagram.com/"
                />
              </div>
            </div>
          </div>
        </div>
        {/* Company Summery */}
        <div className="box">
          <div className="box-header">
            <h4>Company Summery</h4>
          </div>
          <div className="box-body">
            <div className="row">
              <div className="col-sm-12">
                <label>About Company</label>
                <textarea
                  className="form-control height-120 textarea"
                  placeholder="About Company"
                  defaultValue={""}
                />
              </div>
            </div>
          </div>
        </div>
        <div className="text-center">
          <button type="submit" className="btn btn-m theme-btn full-width">
            Submit
          </button>
        </div>
      </form>
    </div>
  </section>
  {/* ====================== End Create Company ================ */}
</>
<Footer/>
   </>
  )
}

export default Createcompany
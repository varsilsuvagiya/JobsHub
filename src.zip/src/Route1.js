import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Home";
import Header from "./Header";
import Footer from "./Footer";
import Signup from "./Signup";
import Createcompany from "./Createcompany";
import Addjob from "./Addjob";
import Searchjob from "./Searchjob";
import Profilesetting from "./Uploadprofile";
import Managejob from "./Managejob";
import Manageresume from "./Manageresume";
import Login from "./Login";
import Error404 from "./Error404";
import Contact from "./Contact";
import Browsecategory from "./Browsecategory";
import Editprofile from "./Editprofile";
import Uploadprofile from "./Uploadprofile";
import Resumedetail from "./Resumedetail";
import Signup1 from "./Signup1";
function Route1() {
  return (
    
      <BrowserRouter>
      
        
      

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/signup1" element={<Signup1 />} />
          <Route path="/createcompany" element={<Createcompany />} />
         <Route path="/addjob" element={<Addjob/>}/>
         <Route path="/searchjob" element={<Searchjob/>}/>
         <Route path="/uploadprofile" element={<Uploadprofile/>}/>
         <Route path="/editprofile" element={<Editprofile/>}/>
         <Route path="/managejob" element={<Managejob/>}/>
         <Route path="/manageresume" element={<Manageresume/>}/>
         <Route path="/login" element={<Login/>}/>
         <Route path="/error" element={<Error404/>}/>
         <Route path="/contact" element={<Contact/>}/>
         <Route path="/browsecategory" element={<Browsecategory/>}/>
         <Route path="/resumedetail" element={<Resumedetail/>}/>
        </Routes>
 
      </BrowserRouter>
    
  );
}

export default Route1;

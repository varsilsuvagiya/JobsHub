import React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from 'react-router-dom';
import { toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
function Login() {
  const navigate = useNavigate();
  const [newData1, setnew1] = useState({
    jsemail: "",
    jspwd: "",
  });
  function update1(e) {
   
    setnew1({ ...newData1, [e.target.name]: e.target.value });
  }
 async function loginapi() {
    
    if (newData1.jsemail === "") {
      alert("enter your Email");
    }
     else if (newData1.jspwd === "") {
      alert("enter your password");
    } 
    else {
      const requestOptions = {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newData1),
      };
      // fetch("http://localhost:8080/login", requestOptions)
      //   .then((response) => response.json())
      //   .then((data1) => navigate("/home"));
        const response = await fetch("http://localhost:8080/login",requestOptions);
        const result = await response.json();
       
        if(result.status===1)
        {
          toast.success("done");
        navigate("/home");
        }                 
       else{
          toast.error("error");
        }
    }
  }
  return (
   <> 
   <div className="page-title">
     <div className="container">
       <div className="page-caption">
         <h2>Login An Account</h2>
         <p>
           <Link to="/home" title="Home">
             Home
           </Link>{" "}
           <i className="ti-angle-double-right" /> Login
         </p>
       </div>
     </div>
   </div>
   {/* ======================= End Page Title ===================== */}
       
        <section className="padd-top-80 padd-bot-80">
          <div className="container">
            <div className="log-box">
              <form className="log-form">
                
                <div className="col-md-6">
                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      name="jsemail"
                      className="form-control"
                      placeholder="Email"
                      onChange={(e) => update1(e)}                  />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <label>Password</label>
                    <input
                      type="password"
                      name="jspwd"
                      className="form-control"
                      placeholder="********"
                      onChange={(e) => update1(e)}
                    />
                  </div>
                  <div className="form-group">
                  {" "}
                 
                  <Link to="/home" title="Forget" className="fl-right">
                    Forgot Password?
                  </Link>
                </div>
                </div>
                
                <div className="col-md-12">
                  <div className="form-group text-center mrg-top-15">
                    <button
                      type="submit"
                      className="btn theme-btn btn-m full-width"
                      onClick={(e) => {
                          loginapi();
                          e.preventDefault();
                        }}
                    >
                      Login
                    </button>
                  </div>
                </div>
                <div className="clearfix" />
              </form>
            </div>
          </div>
        </section>
        
   </>
  )
}

export default Login
import React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { Link } from 'react-router-dom'
import Header from "./Header";
import Footer from "./Footer";
function Signup1() {
  const navigate = useNavigate();
  //registration api
  const [newData, setnew] = useState({
    jsname: "",
    jsemail: "",
    jspwd: "",
    jsrepwd: "",
    jsmno: "",
  });
  function update(e) {
    setnew({ ...newData, [e.target.name]: e.target.value });
  }
async  function submit() {
    if (newData.jsname == "") {
      alert("enter your Name");
    } else if (newData.jsemail == "") {
      alert("enter your email");
    } else if (newData.jspwd == "") {
      alert("enter your password");
    } else if (newData.jspwd == "" || newData.jsrepwd == "") {
      alert("password and retypepasswprd must be same");
    } else if (newData.jsmno == "") {
      alert("enter your mobileno");
    } else {
      const requestOptions = {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newData),
      };
      // fetch("http://localhost:8080/insert", requestOptions)
      //   .then((response) => response.json())
      //   .then((data) => navigate("/login"));
      const response = await fetch("http://localhost:8080/insert",requestOptions);
      const result = await response.json();
    
      if(result.status===1)
      {
        toast.success("Registration Successfully",{position: toast.POSITION.TOP_CENTER});
      navigate("/login");
      }                 
     else{
        toast.error("error");
      }
      
    }
  }
  return (
    <>
    <Header/>
      <>
        {/* ======================= Start Page Title ===================== */}
        <div className="page-title">
          <div className="container">
            <div className="page-caption">
              <h2>Create an Account</h2>
              <p>
                <Link to="/home" title="Home">
                  Home
                </Link>{" "}
                <i className="ti-angle-double-right" /> SignUp
              </p>
            </div>
          </div>
        </div>
        {/* ======================= End Page Title ===================== */}
        {/* ====================== Start Signup Form ============= */}
        <section className="padd-top-80 padd-bot-80">
          <div className="container">
            <div className="log-box">
              <form className="log-form">
                <div className="col-md-6">
                  <div className="form-group">
                    <label>Name</label>
                    <input
                      type="text"
                      name="jsname"
                      className="form-control"
                      placeholder="Name"
                      onChange={(e) => update(e)}
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      name="jsemail"
                      className="form-control"
                      placeholder="Email"
                      onChange={(e) => update(e)}
                    />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label>Password</label>
                    <input
                      type="password"
                      name="jspwd"
                      className="form-control"
                      placeholder="********"
                      onChange={(e) => update(e)}
                    />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label>Confirm Password</label>
                    <input
                      type="password"
                      name="jsrepwd"
                      className="form-control"
                      placeholder="********"
                      onChange={(e) => update(e)}
                    />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label>Phone</label>
                    <input
                      type="text"
                      name="jsmno"
                      className="form-control"
                      placeholder="Phone Number"
                     
                      onChange={(e) => update(e)}
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <label>Certificate</label>
                    <input
                      type="text"
                      name="jscertificate"
                      className="form-control"
                      placeholder="Cerificate No"
                      onChange={(e) => update(e)}
                    />
                  </div>
                </div>
              
                <div className="col-md-6">
                <label>Company Logo</label>
                <div className="custom-file-upload">
                  <input type="file" id="file" name="jslogo" multiple="" />
                </div>
              </div>
                <div className="col-md-12">
                  <div className="form-group text-center mrg-top-15">
                    <button
                      type="submit"
                      className="btn theme-btn btn-m full-width"
                      onClick={(e) => {
                        submit();
                        e.preventDefault();
                      }}
                    >
                      Sign Up
                    </button>
                  </div>
                </div>
                <div className="clearfix" />
              </form>
            </div>
          </div>
        </section>
      </>
 
      <Footer/>
    </>
  );
}

export default Signup1;


import React from 'react'
import { Link } from 'react-router-dom'
import Header4 from './Header4'
import Footer from './Footer'
function Uploadprofile() {
  return (
      <>
      <Header4/>
          <>
  {/* ======================= Page Title ===================== */}
  <div className="page-title">
    <div className="container">
      <div className="page-caption">
        <h2>Profile Settings</h2>
        <p>
          <Link to="/home" title="Home">
            Home
          </Link>{" "}
          <i className="ti-angle-double-right" /> Upload profile
        </p>
      </div>
    </div>
  </div>
  {/* ======================= End Page Title ===================== */}
  {/* ================ Profile Settings ======================= */}
  <section className="padd-top-80 padd-bot-80">
    <div className="container">
      <div className="row">
        <div className="col-md-3">
          <div id="leftcol_item">
            <div className="user_dashboard_pic">
              {" "}
              <img alt="user photo" src="assets/img/user-profile.png" />{" "}
              <span className="user-photo-action">Alden Smith</span>{" "}
            </div>
          </div>
          <div className="dashboard_nav_item">
            <ul>
              <li>
                <a href="dashboard.html">
                  <i className="login-icon ti-dashboard" /> Dashboard
                </a>
              </li>
              <li className="active">
                <Link  to="/editprofile">
                  <i className="login-icon ti-user" /> Edit Profile
                </Link>
              </li>
              <li>
                <a href="change-password.html">
                  <i className="login-icon ti-key" /> Change Password
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="login-icon ti-power-off" /> Logout
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="col-md-9">
          <div className="profile_detail_block">
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>First Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Slogan"
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Last Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Slogan"
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Email</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="mail@example.com"
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Password</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="***********"
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Phone</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="123 214 13247"
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Address</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Address"
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Gender</label>
                <select className="wide form-control">
                  <option data-display="Gender">Gender</option>
                  <option value={1}>Male</option>
                  <option value={2}>Female</option>
                </select>
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Language</label>
                <select className="wide form-control">
                  <option data-display="Language">Language</option>
                  <option value={1}>English</option>
                  <option value={2}>Hindi</option>
                </select>
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Date Of Birth</label>
                <input
                  type="text"
                  id="dob"
                  data-lang="en"
                  data-large-mode="true"
                  data-min-year={2020}
                  data-max-year={2020}
                  data-disabled-days="08/17/2020,08/18/2020"
                  data-id="datedropper-0"
                  data-theme="my-style"
                  className="form-control"
                  readOnly=""
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <label>User Profile</label>
              <div className="custom-file-upload">
                <input type="file" id="file" name="myfiles[]" multiple="" />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Facebook</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://facebook.com/"
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Twitter</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://twitter.com/"
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Linkedin</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://linkedin.com/"
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-xs-12">
              <div className="form-group">
                <label>Google+</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://gmail.com/"
                />
              </div>
            </div>
            <div className="col-md-12 col-sm-12 col-xs-12">
              <div className="form-group">
                <label>Slogan</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="World Most Popular Software Development"
                />
              </div>
            </div>
            <div className="clearfix" />
            <div className="col-md-12 padd-top-10 text-center">
              {" "}
              <a href="#" className="btn btn-m theme-btn full-width">
                Update
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* ================ End Profile Settings ======================= */}
</>
<Footer/>
      </>

  )
}

export default Uploadprofile
import React from 'react'
import loadjs from 'loadjs'
function Load() {
  
  return (

loadjs.reset(),
loadjs("assets/js/jquery.min.js"),
loadjs("assets/plugins/bootstrap/js/bootstrap.min.js"),
loadjs("assets/plugins/bootstrap/js/bootsnav.js"),
loadjs("assets/js/viewportchecker.js"),
loadjs("assets/js/slick.js"),
loadjs("assets/plugins/bootstrap/js/wysihtml5-0.3.0.js"),
loadjs("assets/plugins/bootstrap/js/bootstrap-wysihtml5.js"),
loadjs("assets/plugins/aos-master/aos.js"),
loadjs("assets/plugins/nice-select/js/jquery.nice-select.min.js"),
loadjs("assets/js/custom.js")
// loadjs('assets.mycustom.js')


) 
  
}

export default Load
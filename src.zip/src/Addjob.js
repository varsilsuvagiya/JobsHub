import React, { useEffect, useState } from "react";
import Header3 from "./Header3";
import Footer from "./Footer";
import Select from "react-select";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// import {getcategory,getsalary,getexperience,getjobtype} from './api/common_api';
import { getcategory, insertjob } from "./api/common_api";
import { getsalary } from "./api/common_api";
import { getexperience } from "./api/common_api";
import { getjobtype } from "./api/common_api";
function Addjob() {
  const navigate = useNavigate();
  const [categorydata, setcategorydata] = useState();
  const [salarydata, setsalarydata] = useState();
  const [experiencedata, setexperiencedata] = useState();
  const [jobtypedata, setjobtypedata] = useState();
    const [file, setFile] = useState()
  const [jobdata, setjobdata] = useState({
   
  });
  const onHandleChange = (e) => {
    console.log(e.target.files, "eeeeeeeeeee");
    setFile({ ...file, [e.target.name]: e.target.files[0] })
  }
  //getcategory api call
  const getcategory = async () => {
    const configOption = {
      method: "get",
      headers: { "Content-Type": "application/json" },
    };
    const response = await fetch(
      "http://localhost:8080/get-category",
      configOption
    );
    const result = await response.json();

    let cat_list = [];
    result?.data.map((list) => {
      cat_list.push({ value: list.cid, label: list.cname });
    });
    setcategorydata(cat_list);
    console.log(cat_list);
  };
//  getsalary api call
  const getsalary = async () => {
    const configOption = {
      method: "get",
      headers: { "Content-Type": "application/json" },
    };
    const response = await fetch(
      "http://localhost:8080/get-salary",
      configOption
    );
    const result = await response.json();

    let cat_list = [];
    result?.data.map((list) => {
      cat_list.push({ value: list.id, label: list.salaryamount });
    });
    setsalarydata(cat_list);
  };
  // //getjobtype api call
  const getjobtype = async () => {
    const configOption = {
      method: "get",
      headers: { "Content-Type": "application/json" },
    };
    const response = await fetch(
      "http://localhost:8080/get-jobtype",
      configOption
    );
    const result = await response.json();

    let cat_list = [];
    result?.data.map((list) => {
      cat_list.push({ value: list.id, label: list.jobname });
    });
    setjobtypedata(cat_list);
  };
  // //getexperience api call
  const getexperience = async () => {
    const configOption = {
      method: "get",
      headers: { "Content-Type": "application/json" },
    };
    const response = await fetch(
      "http://localhost:8080/get-experience",
      configOption
    );
    const result = await response.json();

    let cat_list = [];
    result?.data.map((list) => {
      cat_list.push({ value: list.id, label: list.type });
    });
    setexperiencedata(cat_list);
  };
  function update1(e) {
    setjobdata({ ...jobdata, [e.target.name]: e.target.value });
  } 
  const submit = async () => {
    console.log(jobdata);
    if (jobdata.jobtitle === "") {
      alert("enter your jobtitle");
    }
    // if (jobdata.companyname === "") {
    //   alert("enter your companyname");
    // }
    // if (jobdata.category === "") {
    //   alert("enter your category");
    // }
    // if (jobdata.description === "") {
    //   alert("enter your description");
    // }
    // if (jobdata.salary === "") {
    //   alert("enter your salary");
    // }
    // if (jobdata.experience === "") {
    //   alert("enter your experience");
    // }
    // if (jobdata.logo === "") {
    //   alert("enter your logo");
    // }
    // if (jobdata.qualification === "") {
    //   alert("enter your qualification");
    // }
    // if (jobdata.skill === "") {
    //   alert("enter your skill");
    // }
    // if (jobdata.email === "") {
    //   alert("enter your email");
    // }
    // if (jobdata.phoneno === "") {
    //   alert("enter your phoneno");
    // }
    // if (jobdata.websitelink === "") {
    //   alert("enter your websitelink");
    // }
    // if (jobdata.address === "") {
    //   alert("enter your address");
    // }
    // if (jobdata.city === "") {
    //   alert("enter you city");
    // }
    // if (jobdata.state === "") {
    //   alert("enter your state");
    // }
    // if (jobdata.country === "") {
    //   alert("enter your country");
    // }
    // if (jobdata.zipcode === "") {
    //   alert("enter your zipcode");
    // }
    // if (jobdata.facebook === "") {
    //   alert("enter your facebook");
    // }
    // if (jobdata.instagram === "") {
    //   alert("enter your instagram");
    // }
    // if (jobdata.twitter === "") {
    //   alert("enter your twitter");
    // }
    // if (jobdata.google === "") {
    //   alert("enter your google");
    // }


    else {
      const requestOptions = {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(jobdata),
      };
    // fetch("http://localhost:8080/login", requestOptions)
    //   .then((response) => response.json())
    //   .then((data1) => navigate("/home"));
  
      const formData = new FormData();
  
      for (let keys of Object.keys(jobdata.logo)) {
        formData.append("logo", jobdata.logo[keys]);
      }
  
      formData.append("jobtitle", jobdata.jobtitle);
      formData.append("companyname",jobdata.companyname);
      formData.append("category", jobdata.category);
      formData.append("description",jobdata.description);
      formData.append("salary", jobdata.salary);
      formData.append("vacancy", jobdata.vacancy);
      formData.append("experience", jobdata.experience);
      formData.append("logo",jobdata.logo);
      formData.append("jobtype", jobdata.jobtype);
      formData.append("qualification", jobdata.qualification);
      formData.append("skill", jobdata.skill);
      formData.append("email", jobdata.email);
      formData.append("phoneno", jobdata.phoneno);
      formData.append("websitelink", jobdata.websitelink);
      formData.append("address", jobdata.address);
      formData.append("city", jobdata.city);
      formData.append("state", jobdata.state);
      formData.append("country", jobdata.country);
      formData.append("zipcode", jobdata.zipcode);
      formData.append("facebook", jobdata.facebook);
      formData.append("instagram", jobdata.instagram);
      formData.append("twitter", jobdata.twitter);

  
      const response = await insertjob(formData);
  
      console.log(response, "response");
   
  
      

        if(response.status===1)
        {
          toast.success("done");
        navigate("/home");
        }
       else{
          toast.error("error");
        }
    }
   
  };
  useEffect(() => {
    getcategory();
    getsalary();
    getexperience();
    getjobtype();
  }, []);

  return (
    <>
      <Header3 />
      <>
        {/* ======================= Start Page Title ===================== */}
        <div className="page-title">
          <div className="container">
            <div className="page-caption">
              <h2>Add Job</h2>
              <p>
                <Link to="/home" title="Home">
                  Home
                </Link>{" "}
                <i className="ti-angle-double-right" /> Add Job
              </p>
            </div>
          </div>
        </div>
        {/* ======================= End Page Title ===================== */}
        {/* ======================= Create Job ===================== */}
        <section className="create-job padd-top-80 padd-bot-80">
          <div className="container">
            <form className="c-form">
              {/* General Information */}
              <div className="box">
                <div className="box-header">
                  <h4>General Information</h4>
                </div>
                <div className="box-body">
                  <div className="row">
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Job Title</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Job Title"
                        name="jobtitle"
                        value={jobdata.jobtitle}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Company Name</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Company Name"
                        name="companyname"
                        value={jobdata.companyname}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Category</label>
                      {/* <select className="wide form-control" name="category"  onChange={(e) => update1(e)} >
                  <option data-display="Location">
                    Information Of Technology
                  </option>
                 
                </select> */}

                      <Select
                        className="wide form-control"
                        name="category"
                        onChange={(e) => {
                          setjobdata({ ...jobdata, cid: e.value });
                        }}
                        options={categorydata}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                      <label>Description</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Description"
                        name="description"
                        value={jobdata.description}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Salary Range</label>
                      {/* <select className="wide form-control" name="salary"  onChange={(e) => update1(e)} >
                  <option data-display="Salary Range">2,0000</option>
                  <option value={1}>3,0000</option>
                  <option value={2}>4,0000</option>
                </select> */}
                      <Select
                        className="wide form-control"
                        name="salary"
                        onChange={(e) => {
                          setjobdata({ ...jobdata, sid: e.value });
                        }}
                        options={salarydata}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                      <label>No. Of Vacancy</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="No. Of Vacancy"
                        name="vacancy"
                        value={jobdata.vacancy}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                      <label>Experience</label>
                      {/* <select className="wide form-control" name="experience"  onChange={(e) => update1(e)}  >
                  <option data-display="Experience">0 To 6 Month</option>
                  <option value={1}>1 Year</option>
                  <option value={2}>2 Year</option>
                </select> */}
                      <Select
                        className="wide form-control"
                        name="experience"
                        onChange={(e) => {
                          setjobdata({ ...jobdata, eid: e.value });
                        }}
                        options={experiencedata}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                      <label>Company Logo</label>
                      <div className="custom-file-upload">
                        <input
                          type="file"
                          id="file"
                          name="file"
                          multiple=""
                          onChange={(e) => {
                              onHandleChange(e)
                            }}
                        />
                      </div>
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                      <label>Job Type</label>
                      {/* <select className="wide form-control" name="jobtype"  onChange={(e) => update1(e)} >
                  <option data-display="Job Type">Full Time</option>
                  <option value={1}>Part Time</option>
                  <option value={2}>Freelancer</option>
                  </select> */}
                      <Select
                        className="wide form-control"
                        name="jobtype"
                        onChange={(e) => {
                          setjobdata({ ...jobdata, jid: e.value });
                        }}
                        options={jobtypedata}
                      />
                    </div>
                    <div className="col-md-6 col-sm-6 col-xs-12 m-clear">
                      <label>Qualification Required</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Qualification"
                        name="qualification"
                        value={jobdata.qualification}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-6 col-sm-6 col-xs-12">
                      <label>Skills(Seperate with Comma)</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Skills"
                        name="skill"
                        value={jobdata.skill}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                  </div>
                </div>
              </div>
              {/* Company Address */}
              <div className="box">
                <div className="box-header">
                  <h4>Company Address</h4>
                </div>
                <div className="box-body">
                  <div className="row">
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Email</label>
                      <input
                        type="email"
                        className="form-control"
                        placeholder="Email"
                        name="email"
                        value={jobdata.email}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Phone Number</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Phone Number"
                        name="phoneno"
                        value={jobdata.phoneno}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Website Link</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Website Link"
                        name="websitelink"
                        value={jobdata.websitelink}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Address</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Address"
                        name="address"
                        value={jobdata.address}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>City</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Address"
                        name="city"
                        value={jobdata.city}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                      <label>State</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Address"
                        name="state"
                        value={jobdata.state}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                      <label>Country</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Address"
                        name="country"
                        value={jobdata.country}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12 m-clear">
                      <label>Zip Code</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Zip Code"
                        name="zipcode"
                        value={jobdata.zipcode}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                  </div>
                </div>
              </div>
              {/* Social Accounts */}
              <div className="box">
                <div className="box-header">
                  <h4>Social Accounts</h4>
                </div>
                <div className="box-body">
                  <div className="row">
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Facebook</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="https://www.facebook.com/"
                        name="facebook"
                        value={jobdata.facebook}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Instagram</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="http://instagram.com/"
                        name="instagram"
                        value={jobdata.instagram}
                        onChange={(e) => update1(e)}
                      />
                    </div>
                    <div className="col-md-4 col-sm-6 col-xs-12">
                      <label>Twitter</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="https://twitter.com/"
                        name="twitter"
                        value={jobdata.twitter}
                        onChange={(e) => update1(e)}
                      />
                    </div>

                  
                  </div>
                </div>
              </div>
              <div className="text-center">
                <button
                  type="button"
                  className="btn btn-m theme-btn full-width"
                  onClick={(e) => {
                    submit();
                  }}
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </section>
        {/* ====================== End Create Job ================ */}
      </>

      <Footer />
    </>
  );
}

export default Addjob;

import logo from './logo.svg';
import './App.css';
import Home from './Home';
import { Route,BrowserRouter,Routes } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import Route1 from './Route1';
function App() {
  return (
   <>
 
     <Route1/>

   
   </>
  );
}

export default App;

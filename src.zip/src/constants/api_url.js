export const ApiRoutes={
    API_HOSTNAME:"http://localhost:8080/",
    INSERTJOB:"insert-job",
    GETCATEGORY:"get-category",
    GETSALARY:"get-salary",
    GETJOBTYPE:"get-jobtype",
    GETEXPERIENCE:"get-experience",
}
import { ApiHelperGet, ApiHelperPost, ApiHelperFile } from ".";
import { ApiRoutes } from "../constants";

const getcategory = async (data) => {
  try {
    const res = await ApiHelperGet(ApiRoutes.GETCATEGORY);
    return res;
  } catch (error) {
    throw error;
  }
};
const getsalary = async (data) => {
  try {
    const res = await ApiHelperGet(ApiRoutes.GETSALARY);
    return res;
  } catch (error) {
    throw error;
  }
};
const getjobtype = async (data) => {
  try {
    const res = await ApiHelperGet(ApiRoutes.GETJOBTYPE);
    return res;
  } catch (error) {
    throw error;
  }
};
const getexperience = async (data) => {
  try {
    const res = await ApiHelperGet(ApiRoutes.GETJOBTYPE);
    return res;
  } catch (error) {
    throw error;
  }
};
const insertjob = async (data) => {
  try {
    const res = await ApiHelperFile(ApiRoutes.INSERTJOB, data);
    return res;
  } catch (error) {
    throw error;
  }
};

export {

  getexperience,
  getjobtype,
  getsalary,  
  getcategory,
  insertjob,
};

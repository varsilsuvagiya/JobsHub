import React from 'react'
import Header3 from './Header3'
import Footer from './Footer'
import { Link } from 'react-router-dom'
function Managejob() {
  return (
  <><>
  <Header3/>
  {/* ======================= Page Title ===================== */}
  <div className="page-title">
    <div className="container">
      <div className="page-caption">
        <h2>Manage Jobs</h2>
        <p>
          <Link to="/home" title="Home">
            Home
          </Link>{" "}
          <i className="ti-angle-double-right" /> Manage Jobs
        </p>
      </div>
    </div>
  </div>
  {/* ======================= End Page Title ===================== */}
  {/* ======================== Manage Job ========================= */}
  <section className="utf_manage_jobs_area padd-top-80 padd-bot-80">
    <div className="container">
      <div className="table-responsive">
        <table className="table table-lg table-hover">
          <thead>
            <tr>
              <th>Title</th>
              <th>Location</th>
              <th>Email</th>
              <th>Posted</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <a href="job-detail.html">
                  {" "}
                  <img
                    src="assets/img/company_logo_1.png"
                    className="avatar-lg"
                    alt="Avatar"
                  />
                  Software Development <span className="mng-jb">Apple Inc</span>{" "}
                </a>
              </td>
              <td>
                <i className="ti-location-pin" /> 2708 Scenic Way, Sutter
              </td>
              <td>mail@example.com</td>
              <td>
                <i className="ti-credit-card" /> 01 Jan 2021
              </td>
              <td>
                <a
                  href="#"
                  className="cl-success mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Edit"
                >
                  <i className="fa fa-edit" />
                </a>{" "}
                <a
                  href="#"
                  className="cl-danger mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Delete"
                >
                  <i className="fa fa-trash-o" />
                </a>
              </td>
            </tr>
            <tr>
              <td>
                <a href="job-detail.html">
                  {" "}
                  <img
                    src="assets/img/company_logo_2.png"
                    className="avatar-lg"
                    alt="Avatar"
                  />
                  Software Development <span className="mng-jb">Apple Inc</span>{" "}
                </a>
              </td>
              <td>
                <i className="ti-location-pin" /> 2708 Scenic Way, Sutter
              </td>
              <td>mail@example.com</td>
              <td>
                <i className="ti-credit-card" /> 01 Jan 2021
              </td>
              <td>
                <a
                  href="#"
                  className="cl-success mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Edit"
                >
                  <i className="fa fa-edit" />
                </a>{" "}
                <a
                  href="#"
                  className="cl-danger mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Delete"
                >
                  <i className="fa fa-trash-o" />
                </a>
              </td>
            </tr>
            <tr>
              <td>
                <a href="job-detail.html">
                  {" "}
                  <img
                    src="assets/img/company_logo_3.png"
                    className="avatar-lg"
                    alt="Avatar"
                  />
                  Software Development <span className="mng-jb">Apple Inc</span>{" "}
                </a>
              </td>
              <td>
                <i className="ti-location-pin" /> 2708 Scenic Way, Sutter
              </td>
              <td>mail@example.com</td>
              <td>
                <i className="ti-credit-card" /> 01 Jan 2021
              </td>
              <td>
                <a
                  href="#"
                  className="cl-success mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Edit"
                >
                  <i className="fa fa-edit" />
                </a>{" "}
                <a
                  href="#"
                  className="cl-danger mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Delete"
                >
                  <i className="fa fa-trash-o" />
                </a>
              </td>
            </tr>
            <tr>
              <td>
                <a href="job-detail.html">
                  {" "}
                  <img
                    src="assets/img/company_logo_4.png"
                    className="avatar-lg"
                    alt="Avatar"
                  />
                  Software Development <span className="mng-jb">Apple Inc</span>{" "}
                </a>
              </td>
              <td>
                <i className="ti-location-pin" /> 2708 Scenic Way, Sutter
              </td>
              <td>mail@example.com</td>
              <td>
                <i className="ti-credit-card" /> 01 Jan 2021
              </td>
              <td>
                <a
                  href="#"
                  className="cl-success mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Edit"
                >
                  <i className="fa fa-edit" />
                </a>{" "}
                <a
                  href="#"
                  className="cl-danger mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Delete"
                >
                  <i className="fa fa-trash-o" />
                </a>
              </td>
            </tr>
            <tr>
              <td>
                <a href="job-detail.html">
                  {" "}
                  <img
                    src="assets/img/company_logo_5.png"
                    className="avatar-lg"
                    alt="Avatar"
                  />
                  Software Development <span className="mng-jb">Apple Inc</span>{" "}
                </a>
              </td>
              <td>
                <i className="ti-location-pin" /> 2708 Scenic Way, Sutter
              </td>
              <td>mail@example.com</td>
              <td>
                <i className="ti-credit-card" /> 01 Jan 2021
              </td>
              <td>
                <a
                  href="#"
                  className="cl-success mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Edit"
                >
                  <i className="fa fa-edit" />
                </a>{" "}
                <a
                  href="#"
                  className="cl-danger mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Delete"
                >
                  <i className="fa fa-trash-o" />
                </a>
              </td>
            </tr>
            <tr>
              <td>
                <a href="job-detail.html">
                  {" "}
                  <img
                    src="assets/img/company_logo_6.png"
                    className="avatar-lg"
                    alt="Avatar"
                  />
                  Software Development <span className="mng-jb">Apple Inc</span>{" "}
                </a>
              </td>
              <td>
                <i className="ti-location-pin" /> 2708 Scenic Way, Sutter
              </td>
              <td>mail@example.com</td>
              <td>
                <i className="ti-credit-card" /> 01 Jan 2021
              </td>
              <td>
                <a
                  href="#"
                  className="cl-success mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Edit"
                >
                  <i className="fa fa-edit" />
                </a>{" "}
                <a
                  href="#"
                  className="cl-danger mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Delete"
                >
                  <i className="fa fa-trash-o" />
                </a>
              </td>
            </tr>
            <tr>
              <td>
                <a href="job-detail.html">
                  {" "}
                  <img
                    src="assets/img/company_logo_7.png"
                    className="avatar-lg"
                    alt="Avatar"
                  />
                  Software Development <span className="mng-jb">Apple Inc</span>{" "}
                </a>
              </td>
              <td>
                <i className="ti-location-pin" /> 2708 Scenic Way, Sutter
              </td>
              <td>mail@example.com</td>
              <td>
                <i className="ti-credit-card" /> 01 Jan 2021
              </td>
              <td>
                <a
                  href="#"
                  className="cl-success mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Edit"
                >
                  <i className="fa fa-edit" />
                </a>{" "}
                <a
                  href="#"
                  className="cl-danger mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Delete"
                >
                  <i className="fa fa-trash-o" />
                </a>
              </td>
            </tr>
            <tr>
              <td>
                <a href="job-detail.html">
                  {" "}
                  <img
                    src="assets/img/company_logo_8.png"
                    className="avatar-lg"
                    alt="Avatar"
                  />
                  Software Development <span className="mng-jb">Apple Inc</span>{" "}
                </a>
              </td>
              <td>
                <i className="ti-location-pin" /> 2708 Scenic Way, Sutter
              </td>
              <td>mail@example.com</td>
              <td>
                <i className="ti-credit-card" /> 01 Jan 2021
              </td>
              <td>
                <a
                  href="#"
                  className="cl-success mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Edit"
                >
                  <i className="fa fa-edit" />
                </a>{" "}
                <a
                  href="#"
                  className="cl-danger mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Delete"
                >
                  <i className="fa fa-trash-o" />
                </a>
              </td>
            </tr>
            <tr>
              <td>
                <a href="job-detail.html">
                  {" "}
                  <img
                    src="assets/img/company_logo_9.png"
                    className="avatar-lg"
                    alt="Avatar"
                  />
                  Software Development <span className="mng-jb">Apple Inc</span>{" "}
                </a>
              </td>
              <td>
                <i className="ti-location-pin" /> 2708 Scenic Way, Sutter
              </td>
              <td>mail@example.com</td>
              <td>
                <i className="ti-credit-card" /> 01 Jan 2021
              </td>
              <td>
                <a
                  href="#"
                  className="cl-success mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Edit"
                >
                  <i className="fa fa-edit" />
                </a>{" "}
                <a
                  href="#"
                  className="cl-danger mrg-5"
                  data-toggle="tooltip"
                  data-original-title="Delete"
                >
                  <i className="fa fa-trash-o" />
                </a>
              </td>
            </tr>
          </tbody>
        </table>
        <div className="utf_flexbox_area padd-10">
          <ul className="pagination">
            <li className="page-item">
              {" "}
              <a className="page-link" href="#" aria-label="Previous">
                {" "}
                <span aria-hidden="true">«</span>{" "}
                <span className="sr-only">Previous</span>{" "}
              </a>{" "}
            </li>
            <li className="page-item active">
              <a className="page-link" href="#">
                1
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                2
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                3
              </a>
            </li>
            <li className="page-item">
              {" "}
              <a className="page-link" href="#" aria-label="Next">
                {" "}
                <span aria-hidden="true">»</span>{" "}
                <span className="sr-only">Next</span>{" "}
              </a>{" "}
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>
  {/* ====================== End Manage Company ================ */}
</>
<Footer/>
</>

  )
}

export default Managejob